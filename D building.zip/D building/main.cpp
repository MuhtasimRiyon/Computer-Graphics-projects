#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>

# define PI           3.14159265358979323846


GLfloat positionRL = 0.0f;
GLfloat speedRL = 0.05f;

void updateRL(int value) {

    if(positionRL <-1.0)
        positionRL = 1.0f;

    positionRL -= speedRL;

	glutPostRedisplay();


	glutTimerFunc(100, updateRL, 0);
}

GLfloat positionLR = 0.0f;
GLfloat speedLR = 0.05f;
void updateLR(int value) {

    if(positionLR >1.0)
        positionLR = -1.0f;

    positionLR += speedLR;

	glutPostRedisplay();


	glutTimerFunc(100, updateLR, 0);
}

void display() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);         // Clear the color buffer (background)

	//sky
    glBegin(GL_QUADS);
    glColor3ub(105,205,255);
    glVertex2f(-1.0,1.0);
    glVertex2f(1.0,1.0);
    glVertex2f(1.0,0.0);
    glVertex2f(-1.0,0.0);
    glEnd();

    //grass
    glBegin(GL_QUADS);
    glColor3ub(50,200,0);
    glVertex2f(-1.0,0.0);
    glVertex2f(1.0,0.0);
    glVertex2f(1.0,-1.0);
    glVertex2f(-1.0,-1.0);
    glEnd();

	//D building
    glBegin(GL_QUAD_STRIP);
    glColor3ub(160,160,160);
    glVertex2f(-0.8,0.6);
    glVertex2f(-0.8,-0.6);
    glVertex2f(-0.6,0.57);
    glVertex2f(-0.6,-0.6);
    glVertex2f(-0.4,0.6);
    glVertex2f(-0.4,-0.6);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(0,200,200);
    glVertex2f(-0.75,0.5);
    glVertex2f(-0.75,-0.5);
    glVertex2f(-0.6,0.47);
    glVertex2f(-0.6,-0.5);
    glVertex2f(-0.45,0.5);
    glVertex2f(-0.45,-0.5);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(160,160,160);
    glVertex2f(-0.9,0.5);
    glVertex2f(-0.9,-0.6);
    glVertex2f(-0.8,0.6);
    glVertex2f(-0.8,-0.6);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(160,160,160);
    glVertex2f(-0.4,0.6);
    glVertex2f(-0.4,0.0);
    glVertex2f(0.6,0.5);
    glVertex2f(0.6,0.0);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(0,200,200);
    glVertex2f(-0.3,0.5);
    glVertex2f(-0.3,0.4);
    glVertex2f(0.5,0.45);
    glVertex2f(0.5,0.35);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(0,200,200);
    glVertex2f(-0.3,0.3);
    glVertex2f(-0.3,0.2);
    glVertex2f(0.5,0.25);
    glVertex2f(0.5,0.15);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(160,160,160);
    glVertex2f(-0.2,0.1);
    glVertex2f(-0.2,-0.1);
    glVertex2f(0.8,0.0);
    glVertex2f(0.8,-0.2);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(0,200,200);
    glVertex2f(-0.1,0.05);
    glVertex2f(-0.1,-0.05);
    glVertex2f(0.75,-0.025);
    glVertex2f(0.75,-0.125);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(160,160,160);
    glVertex2f(-0.1,-0.1);
    glVertex2f(-0.1,-0.6);
    glVertex2f(0.9,-0.2);
    glVertex2f(0.9,-0.6);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(0,200,200);
    glVertex2f(0.0,-0.2);
    glVertex2f(0.0,-0.3);
    glVertex2f(0.85,-0.25);
    glVertex2f(0.85,-0.35);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(0,200,200);
    glVertex2f(0.0,-0.4);
    glVertex2f(0.0,-0.5);
    glVertex2f(0.85,-0.45);
    glVertex2f(0.85,-0.55);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160,160,160);
    glVertex2f(-0.4,0.1);
    glVertex2f(-0.2,0.1);
    glVertex2f(-0.2,-0.1);
    glVertex2f(-0.1,-0.1);
    glVertex2f(-0.1,-0.6);
    glVertex2f(-0.4,-0.6);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,200,200);
    glVertex2f(-0.45,0.0);
    glVertex2f(-0.3,0.0);
    glVertex2f(-0.3,-0.5);
    glVertex2f(-0.45,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,200,200);
    glVertex2f(-0.3,-0.2);
    glVertex2f(-0.2,-0.2);
    glVertex2f(-0.2,-0.5);
    glVertex2f(-0.3,-0.5);
    glEnd();

    //D building boarder
    glBegin(GL_LINES);
    glColor3f(0,0,0);

    glVertex2f(-0.4,0.1);
    glVertex2f(-0.4,0.6);

    glVertex2f(-0.4,0.1);
    glVertex2f(-0.2,0.1);

    glVertex2f(-0.2,0.1);
    glVertex2f(-0.2,-0.1);

    glVertex2f(-0.2,-0.1);
    glVertex2f(-0.1,-0.1);

    glVertex2f(-0.1,-0.1);
    glVertex2f(-0.1,-0.6);

    glVertex2f(-0.2,0.1);
    glVertex2f(0.8,0.0);

    glVertex2f(-0.1,-0.1);
    glVertex2f(0.9,-0.2);

    glVertex2f(-0.8,0.6);
    glVertex2f(-0.8,-0.6);

    glVertex2f(-0.9,0.5);
    glVertex2f(-0.8,0.6);

    glVertex2f(-0.9,0.5);
    glVertex2f(-0.9,-0.6);

    glVertex2f(-0.9,-0.6);
    glVertex2f(0.9,-0.6);

    glVertex2f(-0.4,0.6);
    glVertex2f(0.6,0.5);

    glVertex2f(0.6,0.02);
    glVertex2f(0.6,0.5);

    glVertex2f(0.8,0.0);
    glVertex2f(0.8,-0.2);

    glVertex2f(0.9,-0.2);
    glVertex2f(0.9,-0.6);

    glEnd();

    glLoadIdentity();

    //cloud
    glPushMatrix();
    glTranslatef(positionLR,0.0f, 0.0f);
    int i;
	glColor3ub(255,255,255);
	GLfloat x=.6f; GLfloat y=.8f; GLfloat radius =.1f;
	int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x1=.5f; GLfloat y1=.8f; GLfloat radius1 =.07f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x1, y1); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x1 + (radius1 * cos(i *  twicePi / triangleAmount)),
			    y1 + (radius1 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x2=.7f; GLfloat y2=.8f; GLfloat radius2 =.07f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x2, y2); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x2 + (radius2 * cos(i *  twicePi / triangleAmount)),
			    y2 + (radius2 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x3=.0f; GLfloat y3=.8f; GLfloat radius3 =.1f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x3, y3); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x3 + (radius3 * cos(i *  twicePi / triangleAmount)),
			    y3 + (radius3 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x4= -0.1f; GLfloat y4=.85f; GLfloat radius4 =.07f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x4, y4); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x4 + (radius4 * cos(i *  twicePi / triangleAmount)),
			    y4 + (radius4 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x5= 0.1f; GLfloat y5=.8f; GLfloat radius5 =.07f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x5, y5); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x5 + (radius5 * cos(i *  twicePi / triangleAmount)),
			    y5 + (radius5 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x6= -0.6f; GLfloat y6=.8f; GLfloat radius6 =.1f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x6, y6); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x6 + (radius6 * cos(i *  twicePi / triangleAmount)),
			    y6 + (radius6 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x7= -0.7f; GLfloat y7=.8f; GLfloat radius7 =.07f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x7, y7); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x7 + (radius7 * cos(i *  twicePi / triangleAmount)),
			    y7 + (radius7 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x8= -0.5f; GLfloat y8=.75f; GLfloat radius8 =.07f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x8, y8); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x8 + (radius8 * cos(i *  twicePi / triangleAmount)),
			    y8 + (radius8 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	glPopMatrix();

	glLoadIdentity();

	glFlush();  // Render now
}

void rain() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);         // Clear the color buffer (background)

	//sky
    glBegin(GL_QUADS);
    glColor3ub(105,205,255);
    glVertex2f(-1.0,1.0);
    glVertex2f(1.0,1.0);
    glVertex2f(1.0,0.0);
    glVertex2f(-1.0,0.0);
    glEnd();

    //grass
    glBegin(GL_QUADS);
    glColor3ub(50,200,0);
    glVertex2f(-1.0,0.0);
    glVertex2f(1.0,0.0);
    glVertex2f(1.0,-1.0);
    glVertex2f(-1.0,-1.0);
    glEnd();

	//D building
    glBegin(GL_QUAD_STRIP);
    glColor3ub(160,160,160);
    glVertex2f(-0.8,0.6);
    glVertex2f(-0.8,-0.6);
    glVertex2f(-0.6,0.57);
    glVertex2f(-0.6,-0.6);
    glVertex2f(-0.4,0.6);
    glVertex2f(-0.4,-0.6);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(0,200,200);
    glVertex2f(-0.75,0.5);
    glVertex2f(-0.75,-0.5);
    glVertex2f(-0.6,0.47);
    glVertex2f(-0.6,-0.5);
    glVertex2f(-0.45,0.5);
    glVertex2f(-0.45,-0.5);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(160,160,160);
    glVertex2f(-0.9,0.5);
    glVertex2f(-0.9,-0.6);
    glVertex2f(-0.8,0.6);
    glVertex2f(-0.8,-0.6);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(160,160,160);
    glVertex2f(-0.4,0.6);
    glVertex2f(-0.4,0.0);
    glVertex2f(0.6,0.5);
    glVertex2f(0.6,0.0);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(0,200,200);
    glVertex2f(-0.3,0.5);
    glVertex2f(-0.3,0.4);
    glVertex2f(0.5,0.45);
    glVertex2f(0.5,0.35);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(0,200,200);
    glVertex2f(-0.3,0.3);
    glVertex2f(-0.3,0.2);
    glVertex2f(0.5,0.25);
    glVertex2f(0.5,0.15);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(160,160,160);
    glVertex2f(-0.2,0.1);
    glVertex2f(-0.2,-0.1);
    glVertex2f(0.8,0.0);
    glVertex2f(0.8,-0.2);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(0,200,200);
    glVertex2f(-0.1,0.05);
    glVertex2f(-0.1,-0.05);
    glVertex2f(0.75,-0.025);
    glVertex2f(0.75,-0.125);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(160,160,160);
    glVertex2f(-0.1,-0.1);
    glVertex2f(-0.1,-0.6);
    glVertex2f(0.9,-0.2);
    glVertex2f(0.9,-0.6);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(0,200,200);
    glVertex2f(0.0,-0.2);
    glVertex2f(0.0,-0.3);
    glVertex2f(0.85,-0.25);
    glVertex2f(0.85,-0.35);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(0,200,200);
    glVertex2f(0.0,-0.4);
    glVertex2f(0.0,-0.5);
    glVertex2f(0.85,-0.45);
    glVertex2f(0.85,-0.55);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160,160,160);
    glVertex2f(-0.4,0.1);
    glVertex2f(-0.2,0.1);
    glVertex2f(-0.2,-0.1);
    glVertex2f(-0.1,-0.1);
    glVertex2f(-0.1,-0.6);
    glVertex2f(-0.4,-0.6);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,200,200);
    glVertex2f(-0.45,0.0);
    glVertex2f(-0.3,0.0);
    glVertex2f(-0.3,-0.5);
    glVertex2f(-0.45,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,200,200);
    glVertex2f(-0.3,-0.2);
    glVertex2f(-0.2,-0.2);
    glVertex2f(-0.2,-0.5);
    glVertex2f(-0.3,-0.5);
    glEnd();

    //D building boarder
    glBegin(GL_LINES);
    glColor3f(0,0,0);

    glVertex2f(-0.4,0.1);
    glVertex2f(-0.4,0.6);

    glVertex2f(-0.4,0.1);
    glVertex2f(-0.2,0.1);

    glVertex2f(-0.2,0.1);
    glVertex2f(-0.2,-0.1);

    glVertex2f(-0.2,-0.1);
    glVertex2f(-0.1,-0.1);

    glVertex2f(-0.1,-0.1);
    glVertex2f(-0.1,-0.6);

    glVertex2f(-0.2,0.1);
    glVertex2f(0.8,0.0);

    glVertex2f(-0.1,-0.1);
    glVertex2f(0.9,-0.2);

    glVertex2f(-0.8,0.6);
    glVertex2f(-0.8,-0.6);

    glVertex2f(-0.9,0.5);
    glVertex2f(-0.8,0.6);

    glVertex2f(-0.9,0.5);
    glVertex2f(-0.9,-0.6);

    glVertex2f(-0.9,-0.6);
    glVertex2f(0.9,-0.6);

    glVertex2f(-0.4,0.6);
    glVertex2f(0.6,0.5);

    glVertex2f(0.6,0.02);
    glVertex2f(0.6,0.5);

    glVertex2f(0.8,0.0);
    glVertex2f(0.8,-0.2);

    glVertex2f(0.9,-0.2);
    glVertex2f(0.9,-0.6);

    glEnd();

    glLoadIdentity();

    //cloud
    glPushMatrix();
    glTranslatef(positionLR,0.0f, 0.0f);
    int i;
	glColor3ub(255,255,255);
	GLfloat x=.6f; GLfloat y=.8f; GLfloat radius =.1f;
	int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x1=.5f; GLfloat y1=.8f; GLfloat radius1 =.07f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x1, y1); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x1 + (radius1 * cos(i *  twicePi / triangleAmount)),
			    y1 + (radius1 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x2=.7f; GLfloat y2=.8f; GLfloat radius2 =.07f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x2, y2); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x2 + (radius2 * cos(i *  twicePi / triangleAmount)),
			    y2 + (radius2 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x3=.0f; GLfloat y3=.8f; GLfloat radius3 =.1f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x3, y3); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x3 + (radius3 * cos(i *  twicePi / triangleAmount)),
			    y3 + (radius3 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x4= -0.1f; GLfloat y4=.85f; GLfloat radius4 =.07f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x4, y4); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x4 + (radius4 * cos(i *  twicePi / triangleAmount)),
			    y4 + (radius4 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x5= 0.1f; GLfloat y5=.8f; GLfloat radius5 =.07f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x5, y5); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x5 + (radius5 * cos(i *  twicePi / triangleAmount)),
			    y5 + (radius5 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x6= -0.6f; GLfloat y6=.8f; GLfloat radius6 =.1f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x6, y6); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x6 + (radius6 * cos(i *  twicePi / triangleAmount)),
			    y6 + (radius6 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x7= -0.7f; GLfloat y7=.8f; GLfloat radius7 =.07f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x7, y7); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x7 + (radius7 * cos(i *  twicePi / triangleAmount)),
			    y7 + (radius7 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat x8= -0.5f; GLfloat y8=.75f; GLfloat radius8 =.07f;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x8, y8); // center of circle
		for(i= 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x8 + (radius8 * cos(i *  twicePi / triangleAmount)),
			    y8 + (radius8 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	glPopMatrix();

	glLoadIdentity();

	//rain
	glPushMatrix();
    glTranslatef(0,positionRL,0.0f);

	glBegin(GL_LINES);
	glColor3f(1,1,1);

    glVertex2f(-0.9,1.6);
	glVertex2f(-0.8,1.7);

	glVertex2f(-0.7,1.6);
	glVertex2f(-0.6,1.7);

	glVertex2f(-0.5,1.6);
	glVertex2f(-0.4,1.7);

	glVertex2f(-0.3,1.6);
	glVertex2f(-0.2,1.7);

	glVertex2f(-0.1,1.6);
	glVertex2f(0.0,1.7);

	glVertex2f(0.1,1.6);
	glVertex2f(0.2,1.7);

	glVertex2f(0.3,1.6);
	glVertex2f(0.4,1.7);

	glVertex2f(0.5,1.6);
	glVertex2f(0.6,1.7);

	glVertex2f(0.7,1.6);
	glVertex2f(0.8,1.7);

	glVertex2f(0.9,1.6);
    glVertex2f(1.0,1.7);

    glVertex2f(-0.9,1.4);
	glVertex2f(-0.8,1.5);

	glVertex2f(-0.7,1.4);
	glVertex2f(-0.6,1.5);

	glVertex2f(-0.5,1.4);
	glVertex2f(-0.4,1.5);

	glVertex2f(-0.3,1.4);
	glVertex2f(-0.2,1.5);

	glVertex2f(-0.1,1.4);
	glVertex2f(0.0,1.5);

	glVertex2f(0.1,1.4);
	glVertex2f(0.2,1.5);

	glVertex2f(0.3,1.4);
	glVertex2f(0.4,1.5);

	glVertex2f(0.5,1.4);
	glVertex2f(0.6,1.5);

	glVertex2f(0.7,1.4);
	glVertex2f(0.8,1.5);

	glVertex2f(0.9,1.4);
    glVertex2f(1.0,1.5);

    glVertex2f(-0.9,1.4);
	glVertex2f(-0.8,1.5);

	glVertex2f(-0.7,1.4);
	glVertex2f(-0.6,1.5);

	glVertex2f(-0.5,1.4);
	glVertex2f(-0.4,1.5);

	glVertex2f(-0.3,1.4);
	glVertex2f(-0.2,1.5);

	glVertex2f(-0.1,1.4);
	glVertex2f(0.0,1.5);

	glVertex2f(0.1,1.4);
	glVertex2f(0.2,1.5);

	glVertex2f(0.3,1.4);
	glVertex2f(0.4,1.5);

	glVertex2f(0.5,1.4);
	glVertex2f(0.6,1.5);

	glVertex2f(0.7,1.4);
	glVertex2f(0.8,1.5);

	glVertex2f(0.9,1.4);
    glVertex2f(1.0,1.5);

    glVertex2f(-0.9,1.2);
	glVertex2f(-0.8,1.3);

	glVertex2f(-0.7,1.2);
	glVertex2f(-0.6,1.3);

	glVertex2f(-0.5,1.2);
	glVertex2f(-0.4,1.3);

	glVertex2f(-0.3,1.2);
	glVertex2f(-0.2,1.3);

	glVertex2f(-0.1,1.2);
	glVertex2f(0.0,1.3);

	glVertex2f(0.1,1.2);
	glVertex2f(0.2,1.3);

	glVertex2f(0.3,1.2);
	glVertex2f(0.4,1.3);

	glVertex2f(0.5,1.2);
	glVertex2f(0.6,1.3);

	glVertex2f(0.7,1.2);
	glVertex2f(0.8,1.3);

	glVertex2f(0.9,1.2);
    glVertex2f(1.0,1.3);

    glVertex2f(-0.9,1.0);
	glVertex2f(-0.8,1.1);

	glVertex2f(-0.7,1.0);
	glVertex2f(-0.6,1.1);

	glVertex2f(-0.5,1.0);
	glVertex2f(-0.4,1.1);

	glVertex2f(-0.3,1.0);
	glVertex2f(-0.2,1.1);

	glVertex2f(-0.1,1.0);
	glVertex2f(0.0,1.1);

	glVertex2f(0.1,1.0);
	glVertex2f(0.2,1.1);

	glVertex2f(0.3,1.0);
	glVertex2f(0.4,1.1);

	glVertex2f(0.5,1.0);
	glVertex2f(0.6,1.1);

	glVertex2f(0.7,1.0);
	glVertex2f(0.8,1.1);

	glVertex2f(0.9,1.0);
    glVertex2f(1.0,1.1);

    glVertex2f(-0.9,0.8);
	glVertex2f(-0.8,0.9);

	glVertex2f(-0.7,0.8);
	glVertex2f(-0.6,0.9);

	glVertex2f(-0.5,0.8);
	glVertex2f(-0.4,0.9);

	glVertex2f(-0.3,0.8);
	glVertex2f(-0.2,0.9);

	glVertex2f(-0.1,0.8);
	glVertex2f(0.0,0.9);

	glVertex2f(0.1,0.8);
	glVertex2f(0.2,0.9);

	glVertex2f(0.3,0.8);
	glVertex2f(0.4,0.9);

	glVertex2f(0.5,0.8);
	glVertex2f(0.6,0.9);

	glVertex2f(0.7,0.8);
	glVertex2f(0.8,0.9);

	glVertex2f(0.9,0.8);
    glVertex2f(1.0,0.9);

	glVertex2f(-0.9,0.6);
	glVertex2f(-0.8,0.7);

	glVertex2f(-0.7,0.6);
	glVertex2f(-0.6,0.7);

	glVertex2f(-0.5,0.6);
	glVertex2f(-0.4,0.7);

	glVertex2f(-0.3,0.6);
	glVertex2f(-0.2,0.7);

	glVertex2f(-0.1,0.6);
	glVertex2f(0.0,0.7);

	glVertex2f(0.1,0.6);
	glVertex2f(0.2,0.7);

	glVertex2f(0.3,0.6);
	glVertex2f(0.4,0.7);

	glVertex2f(0.5,0.6);
	glVertex2f(0.6,0.7);

	glVertex2f(0.7,0.6);
	glVertex2f(0.8,0.7);

	glVertex2f(0.9,0.6);
	glVertex2f(1.0,0.7);

	glVertex2f(-0.9,0.4);
	glVertex2f(-0.8,0.5);

	glVertex2f(-0.7,0.4);
	glVertex2f(-0.6,0.5);

	glVertex2f(-0.5,0.4);
	glVertex2f(-0.4,0.5);

	glVertex2f(-0.3,0.4);
	glVertex2f(-0.2,0.5);

	glVertex2f(-0.1,0.4);
	glVertex2f(0.0,0.5);

	glVertex2f(0.1,0.4);
	glVertex2f(0.2,0.5);

	glVertex2f(0.3,0.4);
	glVertex2f(0.4,0.5);

	glVertex2f(0.5,0.4);
	glVertex2f(0.6,0.5);

	glVertex2f(0.7,0.4);
	glVertex2f(0.8,0.5);

	glVertex2f(0.9,0.4);
	glVertex2f(1.0,0.5);

	glVertex2f(-0.9,0.2);
	glVertex2f(-0.8,0.3);

	glVertex2f(-0.7,0.2);
	glVertex2f(-0.6,0.3);

	glVertex2f(-0.5,0.2);
	glVertex2f(-0.4,0.3);

	glVertex2f(-0.3,0.2);
	glVertex2f(-0.2,0.3);

	glVertex2f(-0.1,0.2);
	glVertex2f(0.0,0.3);

	glVertex2f(0.1,0.2);
	glVertex2f(0.2,0.3);

	glVertex2f(0.3,0.2);
	glVertex2f(0.4,0.3);

	glVertex2f(0.5,0.2);
	glVertex2f(0.6,0.3);

	glVertex2f(0.7,0.2);
	glVertex2f(0.8,0.3);

	glVertex2f(0.9,0.2);
	glVertex2f(1.0,0.3);

	glVertex2f(-0.9,0.0);
	glVertex2f(-0.8,0.1);

	glVertex2f(-0.7,0.0);
	glVertex2f(-0.6,0.1);

	glVertex2f(-0.5,0.0);
	glVertex2f(-0.4,0.1);

	glVertex2f(-0.3,0.0);
	glVertex2f(-0.2,0.1);

	glVertex2f(-0.1,0.0);
	glVertex2f(0.0,0.1);

	glVertex2f(0.1,0.0);
	glVertex2f(0.2,0.1);

	glVertex2f(0.3,0.0);
	glVertex2f(0.4,0.1);

	glVertex2f(0.5,0.0);
	glVertex2f(0.6,0.1);

	glVertex2f(0.7,0.0);
	glVertex2f(0.8,0.1);

	glVertex2f(0.9,0.0);
	glVertex2f(1.0,0.1);

    glVertex2f(-0.9,-0.2);
	glVertex2f(-0.8,-0.1);

	glVertex2f(-0.7,-0.2);
	glVertex2f(-0.6,-0.1);

	glVertex2f(-0.5,-0.2);
	glVertex2f(-0.4,-0.1);

	glVertex2f(-0.3,-0.2);
	glVertex2f(-0.2,-0.1);

	glVertex2f(-0.1,-0.2);
	glVertex2f(0.0,-0.1);

	glVertex2f(0.1,-0.2);
	glVertex2f(0.2,-0.1);

	glVertex2f(0.3,-0.2);
	glVertex2f(0.4,-0.1);

	glVertex2f(0.5,-0.2);
	glVertex2f(0.6,-0.1);

	glVertex2f(0.7,-0.2);
	glVertex2f(0.8,-0.1);

	glVertex2f(0.9,-0.2);
	glVertex2f(1.0,-0.1);

    glVertex2f(-0.9,-0.4);
	glVertex2f(-0.8,-0.3);

	glVertex2f(-0.7,-0.4);
	glVertex2f(-0.6,-0.3);

	glVertex2f(-0.5,-0.4);
	glVertex2f(-0.4,-0.3);

	glVertex2f(-0.3,-0.4);
	glVertex2f(-0.2,-0.3);

	glVertex2f(-0.1,-0.4);
	glVertex2f(0.0,-0.3);

	glVertex2f(0.1,-0.4);
	glVertex2f(0.2,-0.3);

	glVertex2f(0.3,-0.4);
	glVertex2f(0.4,-0.3);

	glVertex2f(0.5,-0.4);
	glVertex2f(0.6,-0.3);

	glVertex2f(0.7,-0.4);
	glVertex2f(0.8,-0.3);

	glVertex2f(0.9,-0.4);
	glVertex2f(1.0,-0.3);

    glVertex2f(-0.9,-0.6);
	glVertex2f(-0.8,-0.5);

	glVertex2f(-0.7,-0.6);
	glVertex2f(-0.6,-0.5);

	glVertex2f(-0.5,-0.6);
	glVertex2f(-0.4,-0.5);

	glVertex2f(-0.3,-0.6);
	glVertex2f(-0.2,-0.5);

	glVertex2f(-0.1,-0.6);
	glVertex2f(0.0,-0.5);

	glVertex2f(0.1,-0.6);
	glVertex2f(0.2,-0.5);

	glVertex2f(0.3,-0.6);
	glVertex2f(0.4,-0.5);

	glVertex2f(0.5,-0.6);
	glVertex2f(0.6,-0.5);

	glVertex2f(0.7,-0.6);
	glVertex2f(0.8,-0.5);

	glVertex2f(0.9,-0.6);
	glVertex2f(1.0,-0.5);

    glVertex2f(-0.9,-0.8);
	glVertex2f(-0.8,-0.7);

	glVertex2f(-0.7,-0.8);
	glVertex2f(-0.6,-0.7);

	glVertex2f(-0.5,-0.8);
	glVertex2f(-0.4,-0.7);

	glVertex2f(-0.3,-0.8);
	glVertex2f(-0.2,-0.7);

	glVertex2f(-0.1,-0.8);
	glVertex2f(0.0,-0.7);

	glVertex2f(0.1,-0.8);
	glVertex2f(0.2,-0.7);

	glVertex2f(0.3,-0.8);
	glVertex2f(0.4,-0.7);

	glVertex2f(0.5,-0.8);
	glVertex2f(0.6,-0.7);

	glVertex2f(0.7,-0.8);
	glVertex2f(0.8,-0.7);

	glVertex2f(0.9,-0.8);
	glVertex2f(1.0,-0.7);

    glVertex2f(-0.9,-1.0);
	glVertex2f(-0.8,-0.9);

	glVertex2f(-0.7,-1.0);
	glVertex2f(-0.6,-0.9);

	glVertex2f(-0.5,-1.0);
	glVertex2f(-0.4,-0.9);

	glVertex2f(-0.3,-1.0);
	glVertex2f(-0.2,-0.9);

	glVertex2f(-0.1,-1.0);
	glVertex2f(0.0,-0.9);

	glVertex2f(0.1,-1.0);
	glVertex2f(0.2,-0.9);

	glVertex2f(0.3,-1.0);
	glVertex2f(0.4,-0.9);

	glVertex2f(0.5,-1.0);
	glVertex2f(0.6,-0.9);

	glVertex2f(0.7,-1.0);
	glVertex2f(0.8,-0.9);

	glVertex2f(0.9,-1.0);
	glVertex2f(1.0,-0.9);

    glVertex2f(-0.9,-1.2);
	glVertex2f(-0.8,-1.1);

	glVertex2f(-0.7,-1.2);
	glVertex2f(-0.6,-1.1);

	glVertex2f(-0.5,-1.2);
	glVertex2f(-0.4,-1.1);

	glVertex2f(-0.3,-1.2);
	glVertex2f(-0.2,-1.1);

	glVertex2f(-0.1,-1.2);
	glVertex2f(0.0,-1.1);

	glVertex2f(0.1,-1.2);
	glVertex2f(0.2,-1.1);

	glVertex2f(0.3,-1.2);
	glVertex2f(0.4,-1.1);

	glVertex2f(0.5,-1.2);
	glVertex2f(0.6,-1.1);

	glVertex2f(0.7,-1.2);
	glVertex2f(0.8,-1.1);

	glVertex2f(0.9,-1.2);
	glVertex2f(1.0,-1.1);

    glVertex2f(-0.9,-1.4);
	glVertex2f(-0.8,-1.3);

	glVertex2f(-0.7,-1.4);
	glVertex2f(-0.6,-1.3);

	glVertex2f(-0.5,-1.4);
	glVertex2f(-0.4,-1.3);

	glVertex2f(-0.3,-1.4);
	glVertex2f(-0.2,-1.3);

	glVertex2f(-0.1,-1.4);
	glVertex2f(0.0,-1.3);

	glVertex2f(0.1,-1.4);
	glVertex2f(0.2,-1.3);

	glVertex2f(0.3,-1.4);
	glVertex2f(0.4,-1.3);

	glVertex2f(0.5,-1.4);
	glVertex2f(0.6,-1.3);

	glVertex2f(0.7,-1.4);
	glVertex2f(0.8,-1.3);

	glVertex2f(0.9,-1.4);
	glVertex2f(1.0,-1.3);

    glVertex2f(-0.9,-1.6);
	glVertex2f(-0.8,-1.5);

	glVertex2f(-0.7,-1.6);
	glVertex2f(-0.6,-1.5);

	glVertex2f(-0.5,-1.6);
	glVertex2f(-0.4,-1.5);

	glVertex2f(-0.3,-1.6);
	glVertex2f(-0.2,-1.5);

	glVertex2f(-0.1,-1.6);
	glVertex2f(0.0,-1.5);

	glVertex2f(0.1,-1.6);
	glVertex2f(0.2,-1.5);

	glVertex2f(0.3,-1.6);
	glVertex2f(0.4,-1.5);

	glVertex2f(0.5,-1.6);
	glVertex2f(0.6,-1.5);

	glVertex2f(0.7,-1.6);
	glVertex2f(0.8,-1.5);

	glVertex2f(0.9,-1.6);
	glVertex2f(1.0,-1.5);

	glPopMatrix();

	glEnd();

	glLoadIdentity();

	glFlush();  // Render now
}

void handleKeypress(unsigned char key, int x, int y) {

	switch (key) {
case 'd':
    glutDisplayFunc(display);
    glutPostRedisplay();
    break;
case 'r':
    glutDisplayFunc(rain);
    glutPostRedisplay();
    break;
	}
}

/* Main function: GLUT runs as a console application starting at main()  */
int main(int argc, char** argv) {
	glutInit(&argc, argv);                 // Initialize GLUT
	glutCreateWindow("OpenGL Setup Test"); // Create a window with the given title
	glutInitWindowSize(320, 320);   // Set the window's initial width & height
	glutDisplayFunc(display); // Register display callback handler for window re-paint
	glutKeyboardFunc(handleKeypress);
	glutTimerFunc(100, updateLR, 0);
	glutTimerFunc(100, updateRL, 0);
	glutMainLoop();           // Enter the event-processing loop
	return 0;
}
