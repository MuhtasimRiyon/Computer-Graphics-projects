#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h

void display1() {
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(-0.2,0.4);
    glVertex2f(-0.1,0.4);
    glVertex2f(-0.1,-0.5);
    glVertex2f(-0.2,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(0.1,0.4);
    glVertex2f(0.2,0.4);
    glVertex2f(0.2,-0.5);
    glVertex2f(0.1,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(-0.4,-0.3);
    glVertex2f(-0.3,-0.3);
    glVertex2f(-0.3,-0.5);
    glVertex2f(-0.4,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(0.3,-0.3);
    glVertex2f(0.4,-0.3);
    glVertex2f(0.4,-0.5);
    glVertex2f(0.3,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(128,128,128);
    glVertex2f(-0.4,-0.2);
    glVertex2f(0.4,-0.2);
    glVertex2f(0.4,-0.3);
    glVertex2f(-0.4,-0.3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255,128,0);
    glVertex2f(-0.3,0.3);
    glVertex2f(0.3,0.3);
    glVertex2f(0.3,0.1);
    glVertex2f(-0.3,0.1);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(255,128,0);
    glVertex2f(-0.4,-0.2);
    glVertex2f(-0.3,0.0);
    glVertex2f(0.4,-0.2);
    glVertex2f(0.3,0.0);
    glEnd();

	glFlush();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("Test");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display1);
	glutMainLoop();
	return 0;
}
