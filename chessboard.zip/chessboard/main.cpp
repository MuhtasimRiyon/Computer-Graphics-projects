#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h

void display1() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_LINES);

    glColor3f(1,0,0);

    glVertex2f(0.8,0.9);
    glVertex2f(0.8,-0.7);

    glVertex2f(-0.8,-0.7);
    glVertex2f(0.8,-0.7);

    glVertex2f(-0.8,0.9);
    glVertex2f(-0.8,-0.7);

    glVertex2f(0.8,0.9);
    glVertex2f(-0.8,0.9);

    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.6,0.9);
    glVertex2f(-0.4,0.9);
    glVertex2f(-0.4,0.7);
    glVertex2f(-0.6,0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.2,0.9);
    glVertex2f(0.0,0.9);
    glVertex2f(0.0,0.7);
    glVertex2f(-0.2,0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.2,0.9);
    glVertex2f(0.4,0.9);
    glVertex2f(0.4,0.7);
    glVertex2f(0.2,0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.6,0.9);
    glVertex2f(0.8,0.9);
    glVertex2f(0.8,0.7);
    glVertex2f(0.6,0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.8,0.7);
    glVertex2f(-0.6,0.7);
    glVertex2f(-0.6,0.5);
    glVertex2f(-0.8,0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.4,0.7);
    glVertex2f(-0.2,0.7);
    glVertex2f(-0.2,0.5);
    glVertex2f(-0.4,0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.0,0.7);
    glVertex2f(0.2,0.7);
    glVertex2f(0.2,0.5);
    glVertex2f(0.0,0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.4,0.7);
    glVertex2f(0.6,0.7);
    glVertex2f(0.6,0.5);
    glVertex2f(0.4,0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.6,0.5);
    glVertex2f(-0.4,0.5);
    glVertex2f(-0.4,0.3);
    glVertex2f(-0.6,0.3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.2,0.5);
    glVertex2f(0.0,0.5);
    glVertex2f(0.0,0.3);
    glVertex2f(-0.2,0.3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.2,0.5);
    glVertex2f(0.4,0.5);
    glVertex2f(0.4,0.3);
    glVertex2f(0.2,0.3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.6,0.5);
    glVertex2f(0.8,0.5);
    glVertex2f(0.8,0.3);
    glVertex2f(0.6,0.3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.8,0.3);
    glVertex2f(-0.6,0.3);
    glVertex2f(-0.6,0.1);
    glVertex2f(-0.8,0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.4,0.3);
    glVertex2f(-0.2,0.3);
    glVertex2f(-0.2,0.1);
    glVertex2f(-0.4,0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.0,0.3);
    glVertex2f(0.2,0.3);
    glVertex2f(0.2,0.1);
    glVertex2f(0.0,0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.4,0.3);
    glVertex2f(0.6,0.3);
    glVertex2f(0.6,0.1);
    glVertex2f(0.4,0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.6,0.1);
    glVertex2f(-0.4,0.1);
    glVertex2f(-0.4,-0.1);
    glVertex2f(-0.6,-0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.2,0.1);
    glVertex2f(0.0,0.1);
    glVertex2f(0.0,-0.1);
    glVertex2f(-0.2,-0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.2,0.1);
    glVertex2f(0.4,0.1);
    glVertex2f(0.4,-0.1);
    glVertex2f(0.2,-0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.6,0.1);
    glVertex2f(0.8,0.1);
    glVertex2f(0.8,-0.1);
    glVertex2f(0.6,-0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.8,-0.1);
    glVertex2f(-0.6,-0.1);
    glVertex2f(-0.6,-0.3);
    glVertex2f(-0.8,-0.3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.4,-0.1);
    glVertex2f(-0.2,-0.1);
    glVertex2f(-0.2,-0.3);
    glVertex2f(-0.4,-0.3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.0,-0.1);
    glVertex2f(0.2,-0.1);
    glVertex2f(0.2,-0.3);
    glVertex2f(0.0,-0.3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.4,-0.1);
    glVertex2f(0.6,-0.1);
    glVertex2f(0.6,-0.3);
    glVertex2f(0.4,-0.3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.6,-0.3);
    glVertex2f(-0.4,-0.3);
    glVertex2f(-0.4,-0.5);
    glVertex2f(-0.6,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.2,-0.3);
    glVertex2f(0.0,-0.3);
    glVertex2f(0.0,-0.5);
    glVertex2f(-0.2,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.2,-0.3);
    glVertex2f(0.4,-0.3);
    glVertex2f(0.4,-0.5);
    glVertex2f(0.2,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.6,-0.3);
    glVertex2f(0.8,-0.3);
    glVertex2f(0.8,-0.5);
    glVertex2f(0.6,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.8,-0.5);
    glVertex2f(-0.6,-0.5);
    glVertex2f(-0.6,-0.7);
    glVertex2f(-0.8,-0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.4,-0.5);
    glVertex2f(-0.2,-0.5);
    glVertex2f(-0.2,-0.7);
    glVertex2f(-0.4,-0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.0,-0.5);
    glVertex2f(0.2,-0.5);
    glVertex2f(0.2,-0.7);
    glVertex2f(0.0,-0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(0.4,-0.5);
    glVertex2f(0.6,-0.5);
    glVertex2f(0.6,-0.7);
    glVertex2f(0.4,-0.7);
    glEnd();

	glFlush();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("Test");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display1);
	glutMainLoop();
	return 0;
}
