#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h

void display1() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_QUADS);
    glColor3f(0,1,0);
    glVertex2f(-0.8,0.7);
    glVertex2f(0.8,0.7);
    glVertex2f(0.8,-0.9);
    glVertex2f(-0.8,-0.9);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(-0.2,-0.2);
    glVertex2f(0.2,-0.2);
    glVertex2f(0.2,-0.9);
    glVertex2f(-0.2,-0.9);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(-0.7,-0.6);
    glVertex2f(-0.5,-0.6);
    glVertex2f(-0.5,-0.8);
    glVertex2f(-0.7,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(-0.7,-0.3);
    glVertex2f(-0.5,-0.3);
    glVertex2f(-0.5,-0.5);
    glVertex2f(-0.7,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(-0.7,0.0);
    glVertex2f(-0.5,0.0);
    glVertex2f(-0.5,-0.2);
    glVertex2f(-0.7,-0.2);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(-0.7,0.3);
    glVertex2f(-0.5,0.3);
    glVertex2f(-0.5,0.1);
    glVertex2f(-0.7,0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(-0.7,0.6);
    glVertex2f(-0.5,0.6);
    glVertex2f(-0.5,0.4);
    glVertex2f(-0.7,0.4);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(0.5,-0.6);
    glVertex2f(0.7,-0.6);
    glVertex2f(0.7,-0.8);
    glVertex2f(0.5,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(0.5,-0.3);
    glVertex2f(0.7,-0.3);
    glVertex2f(0.7,-0.5);
    glVertex2f(0.5,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(0.5,0.0);
    glVertex2f(0.7,0.0);
    glVertex2f(0.7,-0.2);
    glVertex2f(0.5,-0.2);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(0.5,0.3);
    glVertex2f(0.7,0.3);
    glVertex2f(0.7,0.1);
    glVertex2f(0.5,0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102,51,0);
    glVertex2f(0.5,0.6);
    glVertex2f(0.7,0.6);
    glVertex2f(0.7,0.4);
    glVertex2f(0.5,0.4);
    glEnd();

	glFlush();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("Test");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display1);
	glutMainLoop();
	return 0;
}
