#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h

void display1() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_POLYGON);
    glColor3ub(255,255,0);
    glVertex2f(-0.5,0.7);
    glVertex2f(-0.9,0.4);
    glVertex2f(-0.9,-0.3);
    glVertex2f(-0.5,-0.6);
    glVertex2f(0.4,-0.6);
    glVertex2f(0.8,-0.3);
    glVertex2f(0.8,0.4);
    glVertex2f(0.4,0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.0,0.0,0.0);
    glVertex2f(-0.2,0.5);
    glVertex2f(-0.1,0.5);
    glVertex2f(-0.1,0.4);
    glVertex2f(-0.2,0.4);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.0,0.0,0.0);
    glVertex2f(0.0,0.5);
    glVertex2f(0.1,0.5);
    glVertex2f(0.1,0.4);
    glVertex2f(0.0,0.4);

    glBegin(GL_QUADS);
    glColor3f(0,0,0);
    glVertex2f(-0.2,0.4);
    glVertex2f(0.1,0.4);
    glVertex2f(0.1,0.3);
    glVertex2f(-0.2,0.3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0,0,0);
    glVertex2f(-0.3,0.3);
    glVertex2f(0.2,0.3);
    glVertex2f(0.2,-0.2);
    glVertex2f(-0.3,-0.2);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0,0,0);
    glVertex2f(-0.2,-0.2);
    glVertex2f(0.1,-0.2);
    glVertex2f(0.1,-0.3);
    glVertex2f(-0.2,-0.3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0,0,0);
    glVertex2f(-0.1,-0.3);
    glVertex2f(0.0,-0.3);
    glVertex2f(0.0,-0.5);
    glVertex2f(-0.1,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0,0,0);
    glVertex2f(0.2,0.2);
    glVertex2f(0.3,0.2);
    glVertex2f(0.3,-0.3);
    glVertex2f(0.2,-0.3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0,0,0);
    glVertex2f(-0.4,0.2);
    glVertex2f(-0.3,0.2);
    glVertex2f(-0.3,-0.3);
    glVertex2f(-0.4,-0.3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0,0,0);
    glVertex2f(0.3,0.3);
    glVertex2f(0.4,0.3);
    glVertex2f(0.4,-0.2);
    glVertex2f(0.3,-0.2);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0,0,0);
    glVertex2f(-0.5,0.3);
    glVertex2f(-0.4,0.3);
    glVertex2f(-0.4,-0.2);
    glVertex2f(-0.5,-0.2);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0,0,0);
    glVertex2f(0.4,0.3);
    glVertex2f(0.4,0.5);
    glVertex2f(0.5,0.5);
    glVertex2f(0.5,0.4);
    glVertex2f(0.6,0.4);
    glVertex2f(0.6,0.2);
    glVertex2f(0.7,0.3);
    glVertex2f(0.7,-0.2);
    glVertex2f(0.6,-0.2);
    glVertex2f(0.6,-0.3);
    glVertex2f(0.5,-0.3);
    glVertex2f(0.5,-0.4);
    glVertex2f(0.4,-0.4);
    glVertex2f(0.4,-0.2);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0,0,0);
    glVertex2f(0.3,0.5);
    glVertex2f(0.3,0.6);
    glVertex2f(0.4,0.6);
    glVertex2f(0.4,0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0,0,0);
    glVertex2f(0.3,-0.4);
    glVertex2f(0.4,-0.4);
    glVertex2f(0.4,-0.5);
    glVertex2f(0.3,-0.5);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0,0,0);
    glVertex2f(-0.6,0.5);
    glVertex2f(-0.6,0.4);
    glVertex2f(-0.7,0.4);
    glVertex2f(-0.7,0.2);
    glVertex2f(-0.8,0.2);
    glVertex2f(-0.8,-0.2);
    glVertex2f(-0.7,-0.2);
    glVertex2f(-0.7,-0.3);
    glVertex2f(-0.6,-0.3);
    glVertex2f(-0.6,-0.4);
    glVertex2f(-0.5,-0.4);
    glVertex2f(-0.5,0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0,0,0);
    glVertex2f(-0.5,0.6);
    glVertex2f(-0.4,0.6);
    glVertex2f(-0.4,0.5);
    glVertex2f(-0.5,0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0,0,0);
    glVertex2f(-0.5,-0.4);
    glVertex2f(-0.4,-0.4);
    glVertex2f(-0.4,-0.5);
    glVertex2f(-0.5,-0.5);
    glEnd();

	glFlush();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("Test");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display1);
	glutMainLoop();
	return 0;
}
