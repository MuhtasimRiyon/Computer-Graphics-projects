#include<cstdio>
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>
# define PI           3.14159265358979323846

/*void sound()
{
    PlaySound("trains002.wav", NULL, SND_ASYNC|SND_FILENAME|SND_LOOP);
}*/

GLfloat positionRL = 0.0f;
GLfloat speedRL = 0.05f;

void updateRL(int value) {

    if(positionRL <-1.0)
        positionRL = 1.0f;

    positionRL -= speedRL;

	glutPostRedisplay();


	glutTimerFunc(100, updateRL, 0);
}

GLfloat positionLR = 0.0f;
GLfloat speedLR = 0.05f;
void updateLR(int value) {

    if(positionLR >1.0)
        positionLR = -1.0f;

    positionLR += speedLR;

	glutPostRedisplay();


	glutTimerFunc(100, updateLR, 0);
}

void handleMouse(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON){
			speedLR += 0.1f;
			}
			if (button == GLUT_RIGHT_BUTTON)
	{speedLR -= 0.1f;
			}
	glutPostRedisplay();
	}


void SpecialInput(int key, int x, int y)
{
switch(key)
{case GLUT_KEY_UP:
speedRL = 1.0;
break;
case GLUT_KEY_DOWN:
speedRL = 0.2;
break;
glutPostRedisplay();
}
}


GLfloat m = 0.0f;
void Idle()
{
    glutPostRedisplay();//// marks the current window as needing to be redisplayed
}

void night() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    //grass

    glEnable(GL_LIGHTING);//Enable Light Effect

    GLfloat global_ambient[] = {0.0,1.9,0.0, 0.1};//ambient RGBA intensity of light
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, global_ambient);//A lighting model parameter.

    glBegin(GL_QUADS);
    glColor3f(0,1,0);
    glVertex2f(-1.0,-0.5);
    glVertex2f(1.0,-0.5);
    glVertex2f(1.0,-1.0);
    glVertex2f(-1.0,-1.0);
    glEnd();

    glDisable(GL_LIGHTING);//Enable Light Effect

    //field
    glBegin(GL_QUADS);
    glColor3ub(100,50,0);
    glVertex2f(-1.0,0.1);
    glVertex2f(1.0,0.1);
    glVertex2f(1,.0-0.5);
    glVertex2f(-1.0,-0.5);
    glEnd();

    //rail line start
    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-1.0,-0.5);
    glVertex2f(1.0,-0.5);
    glVertex2f(1.0,-0.6);
    glVertex2f(-1.0,-0.6);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-1.0,-0.8);
    glVertex2f(1.0,-0.8);
    glVertex2f(1.0,-0.9);
    glVertex2f(-1.0,-0.9);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.9,-0.6);
    glVertex2f(1.0,-0.6);
    glVertex2f(1.0,-0.8);
    glVertex2f(0.9,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.7,-0.6);
    glVertex2f(0.8,-0.6);
    glVertex2f(0.8,-0.8);
    glVertex2f(0.7,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.5,-0.6);
    glVertex2f(0.6,-0.6);
    glVertex2f(0.6,-0.8);
    glVertex2f(0.5,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.3,-0.6);
    glVertex2f(0.4,-0.6);
    glVertex2f(0.4,-0.8);
    glVertex2f(0.3,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.1,-0.6);
    glVertex2f(0.2,-0.6);
    glVertex2f(0.2,-0.8);
    glVertex2f(0.1,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.1,-0.6);
    glVertex2f(0.0,-0.6);
    glVertex2f(0.0,-0.8);
    glVertex2f(-0.1,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.3,-0.6);
    glVertex2f(-0.2,-0.6);
    glVertex2f(-0.2,-0.8);
    glVertex2f(-0.3,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.5,-0.6);
    glVertex2f(-0.4,-0.6);
    glVertex2f(-0.4,-0.8);
    glVertex2f(-0.5,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.7,-0.6);
    glVertex2f(-0.6,-0.6);
    glVertex2f(-0.6,-0.8);
    glVertex2f(-0.7,-0.8);
    glEnd();

    //rail line end
    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.9,-0.6);
    glVertex2f(-0.8,-0.6);
    glVertex2f(-0.8,-0.8);
    glVertex2f(-0.9,-0.8);
    glEnd();

    //station start
    glBegin(GL_QUADS);
    glColor3ub(127,0,255);
    glVertex2f(-0.2,0.4);
    glVertex2f(0.8,0.4);
    glVertex2f(0.8,-0.1);
    glVertex2f(-0.2,-0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.2,0.1);
    glVertex2f(0.4,0.1);
    glVertex2f(0.4,-0.1);
    glVertex2f(0.2,-0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255,255,255);
    glVertex2f(-0.1,0.3);
    glVertex2f(0.1,0.3);
    glVertex2f(0.1,0.1);
    glVertex2f(-0.1,0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255,255,255);
    glVertex2f(0.5,0.3);
    glVertex2f(0.7,0.3);
    glVertex2f(0.7,0.1);
    glVertex2f(0.5,0.1);
    glEnd();

    glBegin(GL_LINES);
    glColor3ub(0,0,0);

    glVertex2f(0.0,0.1);
    glVertex2f(0.0,0.3);

    glVertex2f(-0.1,0.2);
    glVertex2f(0.1,0.2);

    glVertex2f(0.6,0.1);
    glVertex2f(0.6,0.3);

    glVertex2f(0.5,0.2);
    glVertex2f(0.7,0.2);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,153);
    glVertex2f(-0.2,0.5);
    glVertex2f(0.8,0.5);
    glVertex2f(0.8,0.4);
    glVertex2f(-0.2,0.4);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0,153,153);
    glVertex2f(-0.2,0.5);
    glVertex2f(-0.3,0.4);
    glVertex2f(-0.2,0.4);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0,153,153);
    glVertex2f(0.8,0.5);
    glVertex2f(0.8,0.4);
    glVertex2f(0.9,0.4);
    glEnd();

    //train start
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.1,-0.5);
    glVertex2f(-0.1,-0.7);
    glVertex2f(0.1,-0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.9,-0.5);
    glVertex2f(-0.1,-0.5);
    glVertex2f(-0.1,-0.7);
    glVertex2f(-0.9,-0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(51,255,51);
    glVertex2f(-0.5,-0.3);
    glVertex2f(-0.1,-0.3);
    glVertex2f(-0.1,-0.5);
    glVertex2f(-0.5,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255,255,0);
    glVertex2f(-0.9,-0.1);
    glVertex2f(-0.5,-0.1);
    glVertex2f(-0.5,-0.5);
    glVertex2f(-0.9,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(96,96,96);
    glVertex2f(-0.8,-0.2);
    glVertex2f(-0.6,-0.2);
    glVertex2f(-0.6,-0.4);
    glVertex2f(-0.8,-0.4);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255,0,255);
    glVertex2f(-1.0,0.0);
    glVertex2f(-0.4,0.0);
    glVertex2f(-0.4,-0.1);
    glVertex2f(-1.0,-0.1);
    glEnd();

    //wheel
    int w1;
    glColor3ub(160,160,160);


    GLfloat a = -0.3f; GLfloat b = -0.7f; GLfloat r = 0.1f;
	int tA = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat tPi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a, b); // center of circle
		for( w1 = 0; w1 <= tA; w1++ ) {
			glVertex2f(
		            a + (r * cos(w1 *  tPi / tA)),
			    b + (r * sin(w1 * tPi / tA))
			);
		}
	glEnd();

	//wheel
    int w2;
    glColor3ub(160,160,160);


    GLfloat c1 = -0.7f; GLfloat c2 = -0.7f; GLfloat r1 = 0.1f;
	int tA2 = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat tPi1 = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(c1, c2); // center of circle
		for( w2 = 0; w2 <= tA2; w2++ ) {
			glVertex2f(
		            c1 + (r1 * cos(w2 *  tPi1 / tA2)),
			    c2 + (r1 * sin(w2 * tPi1 / tA2))
			);
		}
	glEnd();

	//train end

    //moon
    int i;
    glColor3f(1,1,1);

    GLfloat x= -0.8f; GLfloat y= 0.8f; GLfloat radius = 0.2f;
	int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

    //windmill
	glBegin(GL_QUADS);
    glColor3ub(96,96,96);
    glVertex2f(-0.75,0.5);
    glVertex2f(-0.65,0.5);
    glVertex2f(-0.65,0.1);
    glVertex2f(-0.75,0.1);
    glEnd();

    glPushMatrix();
    glTranslatef(-0.7,0.5,0.0);
    glScalef(0.5,0.5,0.5);
    glRotatef(m,0.0,0.0,0.1);

    glBegin(GL_QUAD_STRIP);
    glColor3ub(192,192,192);
    glVertex2f(0.0,0.0);
    glVertex2f(-0.1,0.2);
    glVertex2f(0.1,0.2);
    glVertex2f(0.0,0.5);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(192,192,192);
    glVertex2f(0.0,0.0);
    glVertex2f(0.2,0.1);
    glVertex2f(0.2,-0.1);
    glVertex2f(0.5,0.0);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(192,192,192);
    glVertex2f(0.0,0.0);
    glVertex2f(0.1,-0.2);
    glVertex2f(-0.1,-0.2);
    glVertex2f(0.0,-0.5);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(192,192,192);
    glVertex2f(0.0,0.0);
    glVertex2f(-0.2,0.1);
    glVertex2f(-0.2,-0.1);
    glVertex2f(-0.5,0.0);
    glEnd();

    glPopMatrix();
    m-=0.01f;

    glBegin(GL_POINTS);
    glColor3f(1,1,1);
    glPointSize(10);
    glVertex2f(-0.4,0.5);
    glVertex2f(-0.3,0.8);
    glVertex2f(0.4,0.8);
    glVertex2f(0.2,0.7);
    glVertex2f(0.3,0.9);
    glVertex2f(0.2,0.6);
    glEnd();

	glFlush();
}

void demo_night(int val) {

 glutDisplayFunc(night);
}

void day() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    //sky
    glBegin(GL_QUADS);
    glColor3ub(0,130,250);
    glVertex2f(-1.0,1.0);
    glVertex2f(1.0,1.0);
    glVertex2f(1.0,0.0);
    glVertex2f(-1.0,0.0);
    glEnd();

    //grass
    glBegin(GL_QUADS);
    glColor3f(0,1,0);
    glVertex2f(-1.0,-0.5);
    glVertex2f(1.0,-0.5);
    glVertex2f(1.0,-1.0);
    glVertex2f(-1.0,-1.0);
    glEnd();

    //field
    glBegin(GL_QUADS);
    glColor3ub(150,75,0);
    glVertex2f(-1.0,0.1);
    glVertex2f(1.0,0.1);
    glVertex2f(1,.0-0.5);
    glVertex2f(-1.0,-0.5);
    glEnd();

    //rail line start
    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-1.0,-0.5);
    glVertex2f(1.0,-0.5);
    glVertex2f(1.0,-0.6);
    glVertex2f(-1.0,-0.6);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-1.0,-0.8);
    glVertex2f(1.0,-0.8);
    glVertex2f(1.0,-0.9);
    glVertex2f(-1.0,-0.9);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.9,-0.6);
    glVertex2f(1.0,-0.6);
    glVertex2f(1.0,-0.8);
    glVertex2f(0.9,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.7,-0.6);
    glVertex2f(0.8,-0.6);
    glVertex2f(0.8,-0.8);
    glVertex2f(0.7,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.5,-0.6);
    glVertex2f(0.6,-0.6);
    glVertex2f(0.6,-0.8);
    glVertex2f(0.5,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.3,-0.6);
    glVertex2f(0.4,-0.6);
    glVertex2f(0.4,-0.8);
    glVertex2f(0.3,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.1,-0.6);
    glVertex2f(0.2,-0.6);
    glVertex2f(0.2,-0.8);
    glVertex2f(0.1,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.1,-0.6);
    glVertex2f(0.0,-0.6);
    glVertex2f(0.0,-0.8);
    glVertex2f(-0.1,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.3,-0.6);
    glVertex2f(-0.2,-0.6);
    glVertex2f(-0.2,-0.8);
    glVertex2f(-0.3,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.5,-0.6);
    glVertex2f(-0.4,-0.6);
    glVertex2f(-0.4,-0.8);
    glVertex2f(-0.5,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.7,-0.6);
    glVertex2f(-0.6,-0.6);
    glVertex2f(-0.6,-0.8);
    glVertex2f(-0.7,-0.8);
    glEnd();

    //rail line end
    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.9,-0.6);
    glVertex2f(-0.8,-0.6);
    glVertex2f(-0.8,-0.8);
    glVertex2f(-0.9,-0.8);
    glEnd();

    //station start
    glBegin(GL_QUADS);
    glColor3ub(127,0,255);
    glVertex2f(-0.2,0.4);
    glVertex2f(0.8,0.4);
    glVertex2f(0.8,-0.1);
    glVertex2f(-0.2,-0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.2,0.1);
    glVertex2f(0.4,0.1);
    glVertex2f(0.4,-0.1);
    glVertex2f(0.2,-0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255,255,255);
    glVertex2f(-0.1,0.3);
    glVertex2f(0.1,0.3);
    glVertex2f(0.1,0.1);
    glVertex2f(-0.1,0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255,255,255);
    glVertex2f(0.5,0.3);
    glVertex2f(0.7,0.3);
    glVertex2f(0.7,0.1);
    glVertex2f(0.5,0.1);
    glEnd();

    glBegin(GL_LINES);
    glColor3ub(0,0,0);

    glVertex2f(0.0,0.1);
    glVertex2f(0.0,0.3);

    glVertex2f(-0.1,0.2);
    glVertex2f(0.1,0.2);

    glVertex2f(0.6,0.1);
    glVertex2f(0.6,0.3);

    glVertex2f(0.5,0.2);
    glVertex2f(0.7,0.2);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,153);
    glVertex2f(-0.2,0.5);
    glVertex2f(0.8,0.5);
    glVertex2f(0.8,0.4);
    glVertex2f(-0.2,0.4);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0,153,153);
    glVertex2f(-0.2,0.5);
    glVertex2f(-0.3,0.4);
    glVertex2f(-0.2,0.4);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0,153,153);
    glVertex2f(0.8,0.5);
    glVertex2f(0.8,0.4);
    glVertex2f(0.9,0.4);
    glEnd();

    //train start
    glPushMatrix();
    glTranslatef(positionLR,0.0f, 0.0f);
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.1,-0.5);
    glVertex2f(-0.1,-0.7);
    glVertex2f(0.1,-0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.9,-0.5);
    glVertex2f(-0.1,-0.5);
    glVertex2f(-0.1,-0.7);
    glVertex2f(-0.9,-0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(51,255,51);
    glVertex2f(-0.5,-0.3);
    glVertex2f(-0.1,-0.3);
    glVertex2f(-0.1,-0.5);
    glVertex2f(-0.5,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255,255,0);
    glVertex2f(-0.9,-0.1);
    glVertex2f(-0.5,-0.1);
    glVertex2f(-0.5,-0.5);
    glVertex2f(-0.9,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(96,96,96);
    glVertex2f(-0.8,-0.2);
    glVertex2f(-0.6,-0.2);
    glVertex2f(-0.6,-0.4);
    glVertex2f(-0.8,-0.4);
    glEnd();

    //train end
    glBegin(GL_QUADS);
    glColor3ub(255,0,255);
    glVertex2f(-1.0,0.0);
    glVertex2f(-0.4,0.0);
    glVertex2f(-0.4,-0.1);
    glVertex2f(-1.0,-0.1);
    glEnd();

    //wheel
    int w1;
    glColor3ub(160,160,160);


    GLfloat a = -0.3f; GLfloat b = -0.7f; GLfloat r = 0.1f;
	int tA = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat tPi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a, b); // center of circle
		for( w1 = 0; w1 <= tA; w1++ ) {
			glVertex2f(
		            a + (r * cos(w1 *  tPi / tA)),
			    b + (r * sin(w1 * tPi / tA))
			);
		}
	glEnd();

	//wheel
    int w2;
    glColor3ub(160,160,160);


    GLfloat c1 = -0.7f; GLfloat c2 = -0.7f; GLfloat r1 = 0.1f;
	int tA2 = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat tPi1 = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(c1, c2); // center of circle
		for( w2 = 0; w2 <= tA2; w2++ ) {
			glVertex2f(
		            c1 + (r1 * cos(w2 *  tPi1 / tA2)),
			    c2 + (r1 * sin(w2 * tPi1 / tA2))
			);
		}
	glEnd();

	glPopMatrix();

    //sun
    int i;
    glColor3ub(255,255,0);

    GLfloat x= -0.8f; GLfloat y= 0.8f; GLfloat radius = 0.2f;
	int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	//birds
    glPushMatrix();
    glTranslatef(positionRL,0.0f, 0.0f);
    glBegin(GL_LINES);
    glColor3f(0,0,0);

    glVertex2f(0.7,0.7);
    glVertex2f(0.8,0.8);

    glVertex2f(0.7,0.7);
    glVertex2f(0.6,0.8);

    glVertex2f(0.4,0.8);
    glVertex2f(0.5,0.9);

    glVertex2f(0.4,0.8);
    glVertex2f(0.3,0.9);

    glEnd();
    glPopMatrix();

    //windmill
	glBegin(GL_QUADS);
    glColor3ub(96,96,96);
    glVertex2f(-0.75,0.5);
    glVertex2f(-0.65,0.5);
    glVertex2f(-0.65,0.1);
    glVertex2f(-0.75,0.1);
    glEnd();

    glPushMatrix();
    glTranslatef(-0.7,0.5,0.0);
    glScalef(0.5,0.5,0.5);
    glRotatef(m,0.0,0.0,0.1);

    glBegin(GL_QUAD_STRIP);
    glColor3ub(192,192,192);
    glVertex2f(0.0,0.0);
    glVertex2f(-0.1,0.2);
    glVertex2f(0.1,0.2);
    glVertex2f(0.0,0.5);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(192,192,192);
    glVertex2f(0.0,0.0);
    glVertex2f(0.2,0.1);
    glVertex2f(0.2,-0.1);
    glVertex2f(0.5,0.0);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(192,192,192);
    glVertex2f(0.0,0.0);
    glVertex2f(0.1,-0.2);
    glVertex2f(-0.1,-0.2);
    glVertex2f(0.0,-0.5);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(192,192,192);
    glVertex2f(0.0,0.0);
    glVertex2f(-0.2,0.1);
    glVertex2f(-0.2,-0.1);
    glVertex2f(-0.5,0.0);
    glEnd();

    glPopMatrix();//glPopMatrix pops the top matrix off the stack
    m-=0.01f;//i=i+.1=.2

    glutTimerFunc(1500,demo_night,0);


	glFlush();
}

void demo_day(int val) {

 glutDisplayFunc(day);
}

void morning() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    //sky
    glBegin(GL_QUADS);
    glColor3ub(102,178,255);
    glVertex2f(-1.0,1.0);
    glVertex2f(1.0,1.0);
    glVertex2f(1.0,0.0);
    glVertex2f(-1.0,0.0);
    glEnd();

    //grass
    glBegin(GL_QUADS);
    glColor3f(0,1,0);
    glVertex2f(-1.0,-0.5);
    glVertex2f(1.0,-0.5);
    glVertex2f(1.0,-1.0);
    glVertex2f(-1.0,-1.0);
    glEnd();

    //field
    glBegin(GL_QUADS);
    glColor3ub(205,105,0);
    glVertex2f(-1.0,0.1);
    glVertex2f(1.0,0.1);
    glVertex2f(1,.0-0.5);
    glVertex2f(-1.0,-0.5);
    glEnd();

    //rail line start
    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-1.0,-0.5);
    glVertex2f(1.0,-0.5);
    glVertex2f(1.0,-0.6);
    glVertex2f(-1.0,-0.6);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-1.0,-0.8);
    glVertex2f(1.0,-0.8);
    glVertex2f(1.0,-0.9);
    glVertex2f(-1.0,-0.9);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.9,-0.6);
    glVertex2f(1.0,-0.6);
    glVertex2f(1.0,-0.8);
    glVertex2f(0.9,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.7,-0.6);
    glVertex2f(0.8,-0.6);
    glVertex2f(0.8,-0.8);
    glVertex2f(0.7,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.5,-0.6);
    glVertex2f(0.6,-0.6);
    glVertex2f(0.6,-0.8);
    glVertex2f(0.5,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.3,-0.6);
    glVertex2f(0.4,-0.6);
    glVertex2f(0.4,-0.8);
    glVertex2f(0.3,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.1,-0.6);
    glVertex2f(0.2,-0.6);
    glVertex2f(0.2,-0.8);
    glVertex2f(0.1,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.1,-0.6);
    glVertex2f(0.0,-0.6);
    glVertex2f(0.0,-0.8);
    glVertex2f(-0.1,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.3,-0.6);
    glVertex2f(-0.2,-0.6);
    glVertex2f(-0.2,-0.8);
    glVertex2f(-0.3,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.5,-0.6);
    glVertex2f(-0.4,-0.6);
    glVertex2f(-0.4,-0.8);
    glVertex2f(-0.5,-0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.7,-0.6);
    glVertex2f(-0.6,-0.6);
    glVertex2f(-0.6,-0.8);
    glVertex2f(-0.7,-0.8);
    glEnd();

    //rail line end
    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(-0.9,-0.6);
    glVertex2f(-0.8,-0.6);
    glVertex2f(-0.8,-0.8);
    glVertex2f(-0.9,-0.8);
    glEnd();

    //station start
    glBegin(GL_QUADS);
    glColor3ub(127,0,255);
    glVertex2f(-0.2,0.4);
    glVertex2f(0.8,0.4);
    glVertex2f(0.8,-0.1);
    glVertex2f(-0.2,-0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.2,0.1);
    glVertex2f(0.4,0.1);
    glVertex2f(0.4,-0.1);
    glVertex2f(0.2,-0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255,255,255);
    glVertex2f(-0.1,0.3);
    glVertex2f(0.1,0.3);
    glVertex2f(0.1,0.1);
    glVertex2f(-0.1,0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255,255,255);
    glVertex2f(0.5,0.3);
    glVertex2f(0.7,0.3);
    glVertex2f(0.7,0.1);
    glVertex2f(0.5,0.1);
    glEnd();

    glBegin(GL_LINES);
    glColor3ub(0,0,0);

    glVertex2f(0.0,0.1);
    glVertex2f(0.0,0.3);

    glVertex2f(-0.1,0.2);
    glVertex2f(0.1,0.2);

    glVertex2f(0.6,0.1);
    glVertex2f(0.6,0.3);

    glVertex2f(0.5,0.2);
    glVertex2f(0.7,0.2);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0,153,153);
    glVertex2f(-0.2,0.5);
    glVertex2f(0.8,0.5);
    glVertex2f(0.8,0.4);
    glVertex2f(-0.2,0.4);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0,153,153);
    glVertex2f(-0.2,0.5);
    glVertex2f(-0.3,0.4);
    glVertex2f(-0.2,0.4);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0,153,153);
    glVertex2f(0.8,0.5);
    glVertex2f(0.8,0.4);
    glVertex2f(0.9,0.4);
    glEnd();

    //train start
    glPushMatrix();
    glTranslatef(positionLR,0.0f, 0.0f);
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.1,-0.5);
    glVertex2f(-0.1,-0.7);
    glVertex2f(0.1,-0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.9,-0.5);
    glVertex2f(-0.1,-0.5);
    glVertex2f(-0.1,-0.7);
    glVertex2f(-0.9,-0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(51,255,51);
    glVertex2f(-0.5,-0.3);
    glVertex2f(-0.1,-0.3);
    glVertex2f(-0.1,-0.5);
    glVertex2f(-0.5,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255,255,0);
    glVertex2f(-0.9,-0.1);
    glVertex2f(-0.5,-0.1);
    glVertex2f(-0.5,-0.5);
    glVertex2f(-0.9,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(96,96,96);
    glVertex2f(-0.8,-0.2);
    glVertex2f(-0.6,-0.2);
    glVertex2f(-0.6,-0.4);
    glVertex2f(-0.8,-0.4);
    glEnd();

    //train end
    glBegin(GL_QUADS);
    glColor3ub(255,0,255);
    glVertex2f(-1.0,0.0);
    glVertex2f(-0.4,0.0);
    glVertex2f(-0.4,-0.1);
    glVertex2f(-1.0,-0.1);
    glEnd();

    //wheel
    int w1;
    glColor3ub(160,160,160);


    GLfloat a = -0.3f; GLfloat b = -0.7f; GLfloat r = 0.1f;
	int tA = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat tPi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(a, b); // center of circle
		for( w1 = 0; w1 <= tA; w1++ ) {
			glVertex2f(
		            a + (r * cos(w1 *  tPi / tA)),
			    b + (r * sin(w1 * tPi / tA))
			);
		}
	glEnd();

	//wheel
    int w2;
    glColor3ub(160,160,160);


    GLfloat c1 = -0.7f; GLfloat c2 = -0.7f; GLfloat r1 = 0.1f;
	int tA2 = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat tPi1 = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(c1, c2); // center of circle
		for( w2 = 0; w2 <= tA2; w2++ ) {
			glVertex2f(
		            c1 + (r1 * cos(w2 *  tPi1 / tA2)),
			    c2 + (r1 * sin(w2 * tPi1 / tA2))
			);
		}
	glEnd();

	glPopMatrix();

    //sun
    int i;
    glColor3ub(255,200,0);

    GLfloat x= -0.8f; GLfloat y= 0.8f; GLfloat radius = 0.2f;
	int triangleAmount = 20; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	//birds
    glPushMatrix();
    glTranslatef(positionRL,0.0f, 0.0f);
    glBegin(GL_LINES);
    glColor3f(0,0,0);

    glVertex2f(0.7,0.7);
    glVertex2f(0.8,0.8);

    glVertex2f(0.7,0.7);
    glVertex2f(0.6,0.8);

    glVertex2f(0.4,0.8);
    glVertex2f(0.5,0.9);

    glVertex2f(0.4,0.8);
    glVertex2f(0.3,0.9);

    glEnd();
    glPopMatrix();

    //windmill
	glBegin(GL_QUADS);
    glColor3ub(96,96,96);
    glVertex2f(-0.75,0.5);
    glVertex2f(-0.65,0.5);
    glVertex2f(-0.65,0.1);
    glVertex2f(-0.75,0.1);
    glEnd();

    glPushMatrix();
    glTranslatef(-0.7,0.5,0.0);
    glScalef(0.5,0.5,0.5);
    glRotatef(m,0.0,0.0,0.1);

    glBegin(GL_QUAD_STRIP);
    glColor3ub(192,192,192);
    glVertex2f(0.0,0.0);
    glVertex2f(-0.1,0.2);
    glVertex2f(0.1,0.2);
    glVertex2f(0.0,0.5);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(192,192,192);
    glVertex2f(0.0,0.0);
    glVertex2f(0.2,0.1);
    glVertex2f(0.2,-0.1);
    glVertex2f(0.5,0.0);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(192,192,192);
    glVertex2f(0.0,0.0);
    glVertex2f(0.1,-0.2);
    glVertex2f(-0.1,-0.2);
    glVertex2f(0.0,-0.5);
    glEnd();

    glBegin(GL_QUAD_STRIP);
    glColor3ub(192,192,192);
    glVertex2f(0.0,0.0);
    glVertex2f(-0.2,0.1);
    glVertex2f(-0.2,-0.1);
    glVertex2f(-0.5,0.0);
    glEnd();

    glPopMatrix();//glPopMatrix pops the top matrix off the stack
    m-=0.01f;//i=i+.1=.2

    glutTimerFunc(1500,demo_day,0);


	glFlush();
}

void handleKeypress(unsigned char key, int x, int y) {
	switch (key) {
case 'p':
    speedLR = 0.0f;
    break;
case 'r':
    speedLR = 0.1f;
    break;
    glutPostRedisplay();

    //this is for key to call display func
/*case 'd':
    glutDisplayFunc(day);
    glutPostRedisplay();
    break;
case 'n':
   glutDisplayFunc(night);
   glutPostRedisplay();
    break;
case 'm':
   glutDisplayFunc(morning);
   glutPostRedisplay();
    break;*/
	}
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("Test");
	glutInitWindowSize(320, 320);
	glutInitWindowPosition(50, 50);
	glutDisplayFunc(morning);
	//sound();
	glutIdleFunc(Idle);
	glutKeyboardFunc(handleKeypress);
    glutMouseFunc(handleMouse);
    glutSpecialFunc(SpecialInput);
	glutTimerFunc(100, updateRL, 0);
	glutTimerFunc(100, updateLR, 0);
	glutMainLoop();
	return 0;
}
